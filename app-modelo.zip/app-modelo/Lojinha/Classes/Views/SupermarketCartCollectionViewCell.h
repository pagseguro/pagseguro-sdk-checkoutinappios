//
//  SupermarketCartCollectionViewCell.h
//  Lojinha
//
//  Created by TQI on 23/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SupermarketCartCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageProduct;
@property (weak, nonatomic) IBOutlet UILabel *nameProduct;
@property (weak, nonatomic) IBOutlet UILabel *itensProduct;
@property (weak, nonatomic) IBOutlet UILabel *valueItem;
@property (weak, nonatomic) IBOutlet UIView *viewItens;
@property (weak, nonatomic) IBOutlet UIButton *btnEmpty;
@property (weak, nonatomic) IBOutlet UIButton *btnAdd;
@property (weak, nonatomic) IBOutlet UIButton *btnRemove;

- (IBAction)deleteitem:(id)sender;
- (IBAction)removeItem:(id)sender;
- (IBAction)addItem:(id)sender;


@end
