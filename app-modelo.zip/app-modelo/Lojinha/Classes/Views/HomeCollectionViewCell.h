//
//  HomeCollectionViewCell.h
//  ProjetoArquitetura
//
//  Created by TQI on 16/02/17.
//  Copyright © 2017 Tribanco. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemPayment.h"

@interface HomeCollectionViewCell : UICollectionViewCell

@property    ItemPayment * responseObjectProduct;

@property  (strong, nonatomic) UINavigationController *viewController;

@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UILabel *nameProduct;
@property (weak, nonatomic) IBOutlet UILabel *descriptionProduct;
@property (weak, nonatomic) IBOutlet UIView *viewDescription;
@property (weak, nonatomic) IBOutlet UIView *viewPayment;
@property (weak, nonatomic) IBOutlet UILabel *valueProduct;
@property (weak, nonatomic) IBOutlet UIButton *btnPayment;
- (IBAction)btnPayment:(id)sender;

@end
