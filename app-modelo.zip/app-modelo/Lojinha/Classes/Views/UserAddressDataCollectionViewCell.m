//
//  UserAddressDataCollectionViewCell.m
//  CheckOutPagSeguro
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import "UserAddressDataCollectionViewCell.h"
#import "PaymentViewController.h"

@implementation UserAddressDataCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.txtCep.delegate = self;
    [self setLayoutViews:self.btnContinue valid:NO];
    
    [self setLayoutViews:self.txtCity valid:NO];
    [self setLayoutViews:self.txtDistrict valid:NO];
    [self setLayoutViews:self.txtAddress valid:NO];
    [self setLayoutViews:self.txtCep valid:NO];
    [self setLayoutViews:self.txtNumber valid:NO];
    [self setLayoutViews:self.txtComplement valid:NO];
     [self setLayoutViews:self.btnConsultCep valid:NO];
    
    [self.txtComplement  setHidden:YES];
    [self.txtNumber  setHidden:YES];
    [self.txtAddress  setHidden:YES];
    [self.txtDistrict  setHidden:YES];
    [self.txtCity  setHidden:YES];
    
    [self.btnContinue setEnabled:NO];
    self.btnContinue.alpha = 0.5;
    
}
-(void)setLayoutViews:(UIView*)view valid:(BOOL)valid{
    
    view.layer.masksToBounds = valid;
    view.layer.cornerRadius = 5;
    view.layer.shadowOffset = CGSizeMake(0, 0);
    view.layer.shadowRadius = 3;
    view.layer.shadowOpacity = 0.3;
    
}

- (IBAction)btnConsultCep:(id)sender {
    
    [Features startProgressBar:self];
    
    PSCheckoutTransparent *checkoutTransparent = [[PSCheckoutTransparent alloc]init];
    
    
    NSString * cep = [self.txtCep.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    
   checkoutTransparent = [checkoutTransparent initWithPostalCode:cep success:^(BOOL approved, NSDictionary *responseObject) {
        
        [Features stopProgressBar:self];
        
        if (responseObject[@"city"] ) {
            self.itemPayment.user.district =responseObject[@"district"];
            self.itemPayment.user.street =responseObject[@"address"];
            self.itemPayment.user.state =responseObject[@"state"];
            self.itemPayment.user.city =responseObject[@"city"];
            self.itemPayment.user.postalCode =responseObject[@"postalCode"];
            self.itemPayment.user.country =@"Brasil";
            
            self.txtAddress.text =self.itemPayment.user.street;
            self.txtDistrict.text =self.itemPayment.user.district;
            self.txtCity.text =[NSString stringWithFormat:@"%@ - %@",self.itemPayment.user.city ,self.itemPayment.user.state ];
            
            [self.txtComplement  setHidden:NO];
            [self.txtNumber  setHidden:NO];
            [self.txtAddress  setHidden:NO];
            [self.txtDistrict  setHidden:NO];
            [self.txtCity  setHidden:NO];
    
            [self.btnContinue setEnabled:YES];
            self.btnContinue.alpha = 1.0;
            
        }
        
    } failure:^(NSError *error) {
        
        [Features stopProgressBar:self];
        
        self.txtAddress.text = @"";
        self.txtDistrict.text = @"";
        self.txtCity.text = @"";
        
        [self.txtComplement  setHidden:NO];
        [self.txtNumber  setHidden:NO];
        [self.txtAddress  setHidden:NO];
        [self.txtDistrict  setHidden:NO];
        [self.txtCity  setHidden:NO];
        
        [self.txtAddress  setEnabled:YES];
        [self.txtDistrict  setEnabled:YES];
        [self.txtCity  setEnabled:YES];

        [self.btnContinue setEnabled:YES];
        self.btnContinue.alpha = 1.0;

        
    }];
    
}

- (IBAction)btnContinue:(id)sender {
    
    self.itemPayment.user.number =self.txtNumber.text;
    self.itemPayment.user.complement =self.txtComplement.text;
    self.itemPayment.user.district = self.txtDistrict.text;
    self.itemPayment.user.street = self.txtAddress.text;
    self.itemPayment.user.city = self.txtCity.text;
    self.itemPayment.user.postalCode = self.txtCep.text;
    self.itemPayment.user.country =@"Brasil";
    
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    PaymentViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"PaymentViewController"];
    
    paymentViewController.itemPayment = self.itemPayment;
    
    [self.viewController    pushViewController:paymentViewController animated:YES];
    
}

- (BOOL) textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    if (range.location >7) {
        return NO;
    }
    return YES;
}
@end
