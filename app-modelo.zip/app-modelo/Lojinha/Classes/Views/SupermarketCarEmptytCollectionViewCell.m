//
//  SupermarketCarEmptytCollectionViewCell.m
//  Lojinha
//
//  Created by TQI on 24/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "SupermarketCarEmptytCollectionViewCell.h"

@implementation SupermarketCarEmptytCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];

}

@end
