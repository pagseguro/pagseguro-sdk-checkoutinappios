//
//  SupermarketCartCollectionViewCell.m
//  Lojinha
//
//  Created by TQI on 23/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "SupermarketCartCollectionViewCell.h"
#import "SupermarketCartViewController.h"

@implementation SupermarketCartCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    

}




- (IBAction)deleteitem:(id)sender {
}

- (IBAction)removeItem:(id)sender {
    
    if ([self.itensProduct.text integerValue]>1) {
        
        if ([self.itensProduct.text integerValue]==2) {
            [self.btnRemove setImage:[UIImage imageNamed:@"removeItem"] forState:UIControlStateNormal];
            
        }
        self.itensProduct.text = [NSString stringWithFormat:@"%d",[self.itensProduct.text intValue]-1];
        
        [[SupermarketCartViewController sharedInstance]setValuePayment:[self.itensProduct.text intValue] ];

        [self.btnAdd setImage:[UIImage imageNamed:@"addItem-1"] forState:UIControlStateNormal];

    }else{
        
        [self.btnRemove setImage:[UIImage imageNamed:@"removeItem"] forState:UIControlStateNormal];

    }
    
    
}

- (IBAction)addItem:(id)sender {
    
    if ([self.itensProduct.text integerValue]<10) {
        
        if ([self.itensProduct.text integerValue]==9) {
            [self.btnAdd setImage:[UIImage imageNamed:@"addItemGray"] forState:UIControlStateNormal];

        }
        self.itensProduct.text = [NSString stringWithFormat:@"%d",[self.itensProduct.text intValue]+1];
    
        [[SupermarketCartViewController sharedInstance]setValuePayment:[self.itensProduct.text intValue] ];
        
        [self.btnRemove setImage:[UIImage imageNamed:@"removeItemGreen"] forState:UIControlStateNormal];

    }else{
        
        [self.btnAdd setImage:[UIImage imageNamed:@"addItemGray"] forState:UIControlStateNormal];

    }
}
@end
