//
//  MenuCell.h
//  MovieStars
//
//  Created by Luis  Teodoro on 04/01/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *selectionIndicator;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *icoImageView;


@property NSIndexPath *indexPath;
- (void)setupCellForIndexPath;
@end
