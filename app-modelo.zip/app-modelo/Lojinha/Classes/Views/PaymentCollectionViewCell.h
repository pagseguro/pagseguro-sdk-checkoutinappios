//
//  PaymentCollectionViewCell.h
//  InAppPurchase
//
//  Created by TQI on 13/02/17.
//  Copyright © 2017 Luis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIGuidedView.h"
#import <PSCheckoutLib/PSTransparentLib.h>
#import "ItemPayment.h"

@interface PaymentCollectionViewCell : UICollectionViewCell<UIGuidedViewDataSource, UIGuidedViewDelegate>


@property PSTransparentLib *checkoutTransparent;

@property  (strong, nonatomic) UINavigationController *viewController;

@property (strong, nonatomic) IBOutlet UIGuidedView *guidedView;

-(void)setup;
@property (weak, nonatomic) IBOutlet UIView *itemSelected;
@property (weak, nonatomic) IBOutlet UIView *descriptionValue;
@property (weak, nonatomic) IBOutlet UIView *dadosCard;
@property (weak, nonatomic) IBOutlet UIButton *btnConfirmation;

- (IBAction)btnConfirmation:(id)sender;

@property (weak, nonatomic) IBOutlet UILabel *lblNumbercard;
@property (weak, nonatomic) IBOutlet UILabel *lblExpireDate;
@property (weak, nonatomic) IBOutlet UILabel *lblNameUser;



@property (weak, nonatomic) IBOutlet UILabel *lblValueItem;
@property (weak, nonatomic) IBOutlet UILabel *lblValueAll;
@property (weak, nonatomic) IBOutlet UILabel *lblAmount;
@property (weak, nonatomic) IBOutlet UILabel *lblFormaPagamento;


@property (weak, nonatomic) IBOutlet UIImageView *imageItem;
@property (weak, nonatomic) IBOutlet UILabel *nameItem;
@property (weak, nonatomic) IBOutlet UILabel *descriptionItem;


@property   ItemPayment * itemPayment;


@end
