//
//  UserDataCollectionViewCell.h
//  CheckOutPagSeguro
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemPayment.h"
#import "UserDataViewController.h"

@interface UserDataCollectionViewCell : UICollectionViewCell<UITextFieldDelegate>

@property  (strong, nonatomic) UserDataViewController *viewController;
@property   ItemPayment * itemPayment;

@property (weak, nonatomic) IBOutlet UIButton *btnContinue;
@property (weak, nonatomic) IBOutlet UITextField *txtCPF;
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtCel;
@property (weak, nonatomic) IBOutlet UITextField *txtEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtBirthDate;

- (IBAction)btnContinue:(id)sender;
-(void)setup:(ItemPayment *) itemPayment;
@end
