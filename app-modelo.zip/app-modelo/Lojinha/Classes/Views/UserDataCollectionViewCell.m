//
//  UserDataCollectionViewCell.m
//  CheckOutPagSeguro
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import "UserDataCollectionViewCell.h"
#import "UserAddressDataViewController.h"

@implementation UserDataCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.txtCel.delegate = self;
    self.txtCPF.delegate = self;
    self.txtName.delegate = self;
    self.txtBirthDate.delegate = self;

    
    [self setLayoutViews:self.txtCel valid:NO];
    [self setLayoutViews:self.txtCPF valid:NO];
    [self setLayoutViews:self.txtName valid:NO];
    [self setLayoutViews:self.txtEmail valid:NO];
    [self setLayoutViews:self.txtBirthDate valid:NO];
    [self setLayoutViews:self.btnContinue valid:NO];
    
    
    [self inicializaGesto];

    
    [self.btnContinue setEnabled:NO];
    self.btnContinue.alpha = 0.5;
    
}

-(void) inicializaGesto {
    UIGestureRecognizer *gesto  = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickForaTeclado)];
    gesto.cancelsTouchesInView = NO;
    [self addGestureRecognizer:gesto];
}



-(void)clickForaTeclado {
    
    [self ajustaScrollViewPosicaoY:self.viewController.collectionView ePosicaoY:( 0)];

    
    [self  endEditing:YES];
    
}
-(void)setup:(ItemPayment *) itemPayment{
    
    if ([itemPayment.typePayment isEqualToString:@"default"]) {
        
        [self.txtBirthDate setHidden:NO];
    }else{
        
        [self.txtBirthDate setHidden:YES];
        
    }
}

-(void)setLayoutViews:(UIView*)view valid:(BOOL)valid{
    
    view.layer.masksToBounds = valid;
    view.layer.cornerRadius = 5;
    view.layer.shadowOffset = CGSizeMake(0, 0);
    view.layer.shadowRadius = 3;
    view.layer.shadowOpacity = 0.3;
    
}

- (IBAction)btnContinue:(id)sender {
    
     if ([self validaCamposObrigatorios] ){
         
         self.itemPayment.user.cpf = self.txtCPF.text;
         self.itemPayment.user.name = self.txtName.text;
         self.itemPayment.user.email = self.txtEmail.text;
         self.itemPayment.user.birthDate = self.txtBirthDate.text;

         
         NSString * telefone = [self.txtCel.text stringByReplacingOccurrencesOfString:@" " withString:@""];
         telefone = [telefone stringByReplacingOccurrencesOfString:@"-" withString:@""];
         telefone = [telefone stringByReplacingOccurrencesOfString:@"(" withString:@""];
         telefone = [telefone stringByReplacingOccurrencesOfString:@")" withString:@""];
         
         
         if(telefone.length>2){
             
             self.itemPayment.user.phoneAreaCode =  [telefone substringWithRange:NSMakeRange(0, 2)];
             
             self.itemPayment.user.phoneNumber = [telefone substringWithRange:NSMakeRange(2, telefone.length-2)];
             
         }
         
         UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
         
         UserAddressDataViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"UserAddressDataViewController"];
         
         paymentViewController.itemPayment = self.itemPayment;
         
         [self.viewController.navigationController pushViewController:paymentViewController animated:YES];
         
     }
    
   
}

-(BOOL) validaCamposObrigatorios {
    
    NSMutableString *camposObrigatorios = [[NSMutableString alloc] initWithString:@""];
    BOOL camposValidos = YES;
    

    
    if(![self NSStringIsValidEmail:self.txtEmail.text]){
        [camposObrigatorios appendString:@"Por favor, informe um e-mail válido \n"];
        camposValidos = NO;
    }

    if(!camposValidos){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Atenção!" message:camposObrigatorios delegate:self
                                              cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
 
        
    }
        
    return camposValidos;
    
}


- (BOOL) textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField==self.txtEmail) {
        
        if ( self.txtCel.text.length>0
            && self.txtCPF.text.length>0
            && self.txtName.text.length>0 ) {
            if (self.txtBirthDate.isHidden) {
                
                [self.btnContinue setEnabled:YES];
                self.btnContinue.alpha = 1.0;
                
            }else{
                
                if ( self.txtBirthDate.text.length>0){
                    
                    
                    [self.btnContinue setEnabled:YES];
                    self.btnContinue.alpha = 1.0;
                }
                
            }

        }
        
    }
    if (textField==self.txtName) {
        
        if ( self.txtCel.text.length>0
            && self.txtCPF.text.length>0
            && self.txtEmail.text.length>0 ) {
            if (self.txtBirthDate.isHidden) {
                
                [self.btnContinue setEnabled:YES];
                self.btnContinue.alpha = 1.0;
                
            }else{
                
                if ( self.txtBirthDate.text.length>0){
                    
                    
                    [self.btnContinue setEnabled:YES];
                    self.btnContinue.alpha = 1.0;
                }
                
            }

        }
        
    }
    
    
    if (textField==self.txtCPF) {
        
        if ( self.txtCel.text.length>0
            && self.txtEmail.text.length>0
            && self.txtName.text.length>0 ) {
            if (self.txtBirthDate.isHidden) {
                
                [self.btnContinue setEnabled:YES];
                self.btnContinue.alpha = 1.0;
                
            }else{
                
                if ( self.txtBirthDate.text.length>0){
                    
                    
                    [self.btnContinue setEnabled:YES];
                    self.btnContinue.alpha = 1.0;
                }
                
            }
        }
        
        if (range.location >13) {
            return NO;
        }
        
        // Auto-add hyphen
        if (range.length == 0 && range.location == 3 ) {
            textField.text = [NSString stringWithFormat:@"%@.%@", textField.text,string];
            return NO;
        }
        if (range.length == 0 && range.location == 7 ) {
            textField.text = [NSString stringWithFormat:@"%@.%@", textField.text,string];
            return NO;
        }
        
        if (range.length == 0 && range.location == 11 ) {
            textField.text = [NSString stringWithFormat:@"%@-%@", textField.text,string];
            return NO;
        }
    }
    
    if (textField == self.txtCel ) {
        
        if ( self.txtCPF.text.length>0
            && self.txtEmail.text.length>0
            && self.txtName.text.length>0 ) {
            
            if (self.txtBirthDate.isHidden) {
                
                [self.btnContinue setEnabled:YES];
                self.btnContinue.alpha = 1.0;
                
            }else{
                
                if ( self.txtBirthDate.text.length>0){
                    
                    
                    [self.btnContinue setEnabled:YES];
                    self.btnContinue.alpha = 1.0;
                }

            }
            

        }
        
        
        if (range.location >14) {
            return NO;
        }else if(range.location <14){
            
            NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
            NSArray *components = [newString componentsSeparatedByCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
            NSString *decimalString = [components componentsJoinedByString:@""];
            
            NSUInteger length = decimalString.length;
            BOOL hasLeadingOne = length > 0 && [decimalString characterAtIndex:0] == '1';
            
            if (length == 0 || (length > 10 && !hasLeadingOne) || (length > 11)) {
                textField.text = decimalString;
                return NO;
            }
            
            NSUInteger index = 0;
            NSMutableString *formattedString = [NSMutableString string];
            
            
            if (length - index > 2) {
                NSString *areaCode = [decimalString substringWithRange:NSMakeRange(index, 2)];
                [formattedString appendFormat:@"(%@) ",areaCode];
                index += 2;
            }
            
            if (length - index > 5) {
                NSString *prefix = [decimalString substringWithRange:NSMakeRange(index, 5)];
                [formattedString appendFormat:@"%@-",prefix];
                index += 5;
            }
            
            
            NSString *remainder = [decimalString substringFromIndex:index];
            [formattedString appendString:remainder];
            
            textField.text = formattedString;
            
            return NO;
        }
        
        if (range.length==1 && string.length==0){
            
            return YES;
        }
        
        
        if(range.location == 14){
            
            self.txtCel.text = [NSString stringWithFormat:@"%@%@", self.txtCel.text , string];
            string=nil;
            
        }
        // Reject appending non-digit characters
        if (range.length == 0 && string==nil) {
            return NO;
        }
    }
    
    if (textField==self.txtBirthDate) {
        

        if ( self.txtCel.text.length>0
            && self.txtEmail.text.length>0
            && self.txtName.text.length>0 && self.txtBirthDate.text.length>0) {
            [self.btnContinue setEnabled:YES];
            self.btnContinue.alpha = 1.0;
        }
        
        if (range.location >9) {
            return NO;
        }
        
        // Auto-add hyphen
        if (range.length == 0 && range.location == 2 ) {
            textField.text = [NSString stringWithFormat:@"%@/%@", textField.text,string];
            return NO;
        }
        if (range.length == 0 && range.location == 5 ) {
            textField.text = [NSString stringWithFormat:@"%@/%@", textField.text,string];
            return NO;
        }
        
      
    }

    
    
    return YES;
    
}

-(void) ajustaScrollViewPosicaoY: (UIScrollView *) scrollViewElemento  ePosicaoY: (int) posicaoY {
    [scrollViewElemento setContentOffset: CGPointMake(0, posicaoY) animated:YES];
    
}

-(void) textFieldDidBeginEditing:(UITextField *)textField {
    int sizeView =  ([[UIScreen mainScreen]bounds].size.height);
    
    if (sizeView <= 568) {
        
           if (textField == self.txtBirthDate  || textField == self.txtCel || textField == self.txtEmail ) {
               [self ajustaScrollViewPosicaoY: self.viewController.collectionView ePosicaoY:(textField.center.y - 110)];

           }
        
      
    }
}

-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}
@end
