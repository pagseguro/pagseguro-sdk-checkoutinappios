//
//  HomeCollectionViewCell.m
//  ProjetoArquitetura
//
//  Created by TQI on 16/02/17.
//  Copyright © 2017 Tribanco. All rights reserved.
//

#import "HomeCollectionViewCell.h"
#import "SupermarketCartViewController.h"


@implementation HomeCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.btnPayment.layer.masksToBounds = NO;
    self.btnPayment.layer.cornerRadius = 5;
    
    
}

- (IBAction)btnPayment:(id)sender{
    
    UIStoryboard *board=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
  
    if ([SupermarketCartViewController sharedInstance]==nil) {
        SupermarketCartViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"SupermarketCartViewController"];
        
        paymentViewController.responseObjectProduct = self.responseObjectProduct;
        [SupermarketCartViewController sharedInstance:paymentViewController];
        
        [self.viewController pushViewController:[SupermarketCartViewController sharedInstance] animated:YES];


        
    }else{
        [self.viewController pushViewController:[SupermarketCartViewController sharedInstance] animated:YES];

        
    }
    

    
    
    
}

@end
