//
//  SupermarketCarEmptytCollectionViewCell.h
//  Lojinha
//
//  Created by TQI on 24/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SupermarketCarEmptytCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIView *viewItens;

@end
