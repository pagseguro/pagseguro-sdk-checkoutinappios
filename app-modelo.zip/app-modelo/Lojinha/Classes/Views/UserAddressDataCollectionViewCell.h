//
//  UserAddressDataCollectionViewCell.h
//  CheckOutPagSeguro
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemPayment.h"
#import <PSCheckoutLib/PSTransparentLib.h>
#import "Features.h"

@interface UserAddressDataCollectionViewCell : UICollectionViewCell<UITextFieldDelegate,SearchPostalCodeDelegate>


@property   ItemPayment * itemPayment;
@property  (strong, nonatomic) UINavigationController *viewController;
@property (weak, nonatomic) IBOutlet UITextField *txtCep;
@property (weak, nonatomic) IBOutlet UIButton *btnContinue;
@property (weak, nonatomic) IBOutlet UITextField *txtNumber;
@property (weak, nonatomic) IBOutlet UITextField *txtComplement;

@property (weak, nonatomic) IBOutlet UITextField *txtDistrict;
@property (weak, nonatomic) IBOutlet UITextField *txtAddress;
@property (weak, nonatomic) IBOutlet UITextField *txtCity;
@property (weak, nonatomic) IBOutlet UIButton *btnConsultCep;

- (IBAction)btnConsultCep:(id)sender;
- (IBAction)btnContinue:(id)sender;

@end
