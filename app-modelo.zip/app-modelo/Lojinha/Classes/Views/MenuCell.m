//
//  MenuCell.m
//  MovieStars
//
//  Created by Luis  Teodoro on 04/01/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "MenuCell.h"
#import "Constants.h"

@implementation MenuCell
- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    self.selectionIndicator.hidden = YES;
    self.backgroundColor =  selected ? UIColorFromHex(0xEDEDED) : [UIColor whiteColor];
    
    
}

- (void)setupCellForIndexPath{
    switch (self.indexPath.section) {
        case 0:{
            self.titleLabel.text = @"Home";
            self.icoImageView.image = [UIImage imageNamed:@"Cart"];
        }
            break;
        case 1:{
            self.titleLabel.text = @"Sobre";
            self.icoImageView.image = [UIImage imageNamed:@"info"];
        }
            break;

       
        default:
            break;
    }
}

@end
