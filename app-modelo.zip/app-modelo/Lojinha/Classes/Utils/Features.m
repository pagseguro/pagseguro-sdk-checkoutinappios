//
//  Features.m
//  Lojinha
//
//  Created by TQI on 23/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "Features.h"

#define UIColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

static AMTumblrHud *tumblrHUD;


@implementation Features

+(void)startProgressBar:(UIView*)view{
    
    UIView * viewNew  = [[UIView alloc]init];
    viewNew.tag  = 1;
    
    viewNew.frame =CGRectMake(round((view.frame.size.width - 120) / 2), round((view.frame.size.height - 120) / 2), 120, 120);
    
    UIImage * image  = [UIImage imageNamed:@"background.png"];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
    
    imageView.frame = CGRectMake(round((viewNew.frame.size.width - 120) / 2), round((viewNew.frame.size.height - 120) / 2), 120, 120);
    
    [viewNew addSubview:imageView];
    
    UIActivityIndicatorView  *av = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray] ;
    av.frame = CGRectMake(round((viewNew.frame.size.width - 25) / 2), round((viewNew.frame.size.height - 25) / 2), 25, 25);
    
    av.color= UIColorFromRGB(0x41C0C3);
    
    av.transform = CGAffineTransformMakeScale(2.5, 2.5);
    
    [viewNew addSubview:av];
    
    [view addSubview:viewNew];
    [av startAnimating];
    
    viewNew.layer.masksToBounds = YES;
    viewNew.layer.cornerRadius = 10;
    
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    
}

/**
 * Finaliza o progress progressBar
 * @author Luis Teodoro
 */
+(void)stopProgressBar:(UIView*)view{
    
    
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    
    UIActivityIndicatorView *tmpimg = (UIActivityIndicatorView *)[view viewWithTag:1];
    [tmpimg removeFromSuperview];
}



@end
