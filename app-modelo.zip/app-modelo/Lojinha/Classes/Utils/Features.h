//
//  Features.h
//  Lojinha
//
//  Created by TQI on 23/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "AMTumblrHud.h"

@interface Features : NSObject
    
+(void)startProgressBar:(UIView*)view;
+(void)stopProgressBar:(UIView*)view;
@end
