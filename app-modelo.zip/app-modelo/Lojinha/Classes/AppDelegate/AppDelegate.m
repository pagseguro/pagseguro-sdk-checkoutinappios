//
//  AppDelegate.m
//  Lojinha
//
//  Created by TQI on 21/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "AppDelegate.h"
#import "HomeViewController.h"
#import "SlideNavigationController.h"
#import "MenuViewController.h"
#import "Constants.h"

@interface AppDelegate (){
    
    id controllerView;

}
@end

@implementation AppDelegate

- (void)changeRootViewControllerTo:(UIViewController*)newRootViewController{
    [UIView transitionFromView:self.window.rootViewController.view
                        toView:newRootViewController.view
                      duration:0.65f
                       options:UIViewAnimationOptionTransitionFlipFromLeft
                    completion:^(BOOL finished){
                        self.window.rootViewController = newRootViewController;
                    }];
}

- (void)changeRootViewControllerToHub{
    [[SlideNavigationController sharedInstance] viewWillLayoutSubviews];
    [SlideNavigationController sharedInstance].lastRevealedMenu = 0;
    
    [UIView transitionFromView:self.window.rootViewController.view
                        toView:[SlideNavigationController sharedInstance].view
                      duration:0.65f
                       options:UIViewAnimationOptionTransitionFlipFromLeft
                    completion:^(BOOL finished){
                        self.window.rootViewController = [SlideNavigationController sharedInstance];
                    }];
}


- (void)slideNavigationControllerSetup{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    MenuViewController *menu = (MenuViewController*)[mainStoryboard instantiateViewControllerWithIdentifier: @"MenuViewController"];
    [SlideNavigationController sharedInstance].leftMenu = menu;
    
    //-- Botão Menu
    UIButton *button  = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    [button setImage:[UIImage imageNamed:@"BTN_MENU"] forState:UIControlStateNormal];
    [button addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleLeftMenu) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    [SlideNavigationController sharedInstance].leftBarButtonItem = leftBarButtonItem;
}

-(void)direction{
    
    [self slideNavigationControllerSetup];
    
    NSString *vcID = @"HomeViewController";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController *vc = [storyboard instantiateViewControllerWithIdentifier:vcID];
    controllerView= [[SlideNavigationController sharedInstance] initWithRootViewController:vc];
    
    [AppDelegateMacro changeRootViewControllerToHub];
    
    
}



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self direction];
   
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];

    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
