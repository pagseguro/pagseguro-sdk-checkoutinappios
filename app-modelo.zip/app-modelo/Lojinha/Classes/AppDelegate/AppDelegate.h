//
//  AppDelegate.h
//  Lojinha
//
//  Created by TQI on 21/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

- (void)changeRootViewControllerTo:(UIViewController*)newRootViewController;
- (void)changeRootViewControllerToHub;
-(void)direction;
- (void)slideNavigationControllerSetup;
@end

