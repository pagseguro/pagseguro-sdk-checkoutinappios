//
//  User.h
//  CheckOutPagSeguro
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject

@property (strong, nonatomic) NSString * email;
@property (strong, nonatomic) NSString * name;
@property (strong, nonatomic) NSString * cpf;
@property (strong, nonatomic) NSString * phoneAreaCode;
@property (strong, nonatomic) NSString * phoneNumber;
@property (strong, nonatomic) NSString * country;
@property (strong, nonatomic) NSString * state;
@property (strong, nonatomic) NSString * city;
@property (strong, nonatomic) NSString * postalCode;
@property (strong, nonatomic) NSString * district;
@property (strong, nonatomic) NSString * street;
@property (strong, nonatomic) NSString * number;
@property (strong, nonatomic) NSString * complement;
@property (strong, nonatomic)  NSString *birthDate;

@end
