//
//  ItemPayment.h
//  InAppPurchase
//
//  Created by TQI on 13/02/17.
//  Copyright © 2017 Luis. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "User.h"


@interface ItemPayment : NSObject

@property (strong, nonatomic)  NSString *imageItem;
@property (strong, nonatomic)  NSString *nameItem;
@property (strong, nonatomic)  NSString *descriptionItem;
@property (strong, nonatomic)  NSString *valueItem;
@property (strong, nonatomic)  NSString *valueAll;
@property (strong, nonatomic)  NSString *amountAll;
@property (strong, nonatomic)  NSString *valueInstallment;
@property (strong, nonatomic)  NSString *typePayment;
@property (strong, nonatomic)  User * user;

@property (strong, nonatomic)  NSString *nameUser;
@property (strong, nonatomic)  NSString *numberCard;
@property (strong, nonatomic)  NSString *expireDate;
@property (strong, nonatomic)  NSString *CVV;
@property (strong, nonatomic)  NSString *quantity;
@property (strong, nonatomic)  NSString *extraAmount;





@end
