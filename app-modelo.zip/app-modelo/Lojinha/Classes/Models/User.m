//
//  User.m
//  CheckOutPagSeguro
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import "User.h"

@implementation User
@synthesize email,name,cpf,phoneAreaCode,phoneNumber,country,state,city,postalCode,district,street,number,complement, birthDate;

@end
