//
//  ItemPayment.m
//  InAppPurchase
//
//  Created by TQI on 13/02/17.
//  Copyright © 2017 Luis. All rights reserved.
//

#import "ItemPayment.h"

@implementation ItemPayment

@synthesize imageItem, nameItem, valueItem, valueAll, amountAll, descriptionItem, valueInstallment, user, numberCard, nameUser, expireDate, CVV, quantity, extraAmount;

@end

