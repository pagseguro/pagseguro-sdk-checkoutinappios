//
//  LJLJAMPActivityIndicator.h
//  Lojinha
//
//  Created by TQI on 23/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface LJAMPActivityIndicator : UIView

@property (nonatomic) UIColor *barColor;
@property (nonatomic) CGFloat barWidth;
@property (nonatomic) CGFloat barHeight;
@property (nonatomic) CGFloat aperture;

- (void)startAnimating;
- (void)stopAnimating;
- (BOOL)isAnimating;

@end
