//
//  
//  ProjetoMenu
//
//  Created by TQI on 01/02/17.
//  Copyright © 2017 Luis. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface UIBezierPath (Center)

- (CGPoint)center;

@end
