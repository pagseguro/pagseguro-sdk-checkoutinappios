//
//  UserDataViewController.h
//  CheckOutPagSeguro
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemPayment.h"
@interface UserDataViewController : UIViewController
@property   ItemPayment * itemPayment;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end
