//
//  HomeViewController.m
//  Lojinha
//
//  Created by TQI on 21/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "HomeViewController.h"
#import "SlideNavigationController.h"
#import "HomeCollectionViewCell.h"
#import "HomeController.h"
#import "Features.h"
#import "ItemPayment.h"


static int fade ;

@interface HomeViewController ()< UICollectionViewDelegate, UICollectionViewDataSource>{
    
    ItemPayment * itemPayment ;
}
@property (weak, nonatomic) IBOutlet UIView *viewFade;

@property (weak, nonatomic) IBOutlet UICollectionView *homeCollectionView;
- (IBAction)menu:(id)sender;
@property (strong, nonatomic) HomeController *homeController;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constrainHeader;

@end

@implementation HomeViewController

- (void)viewDidLoad {
    
    if (fade==0) {
        [UIView animateWithDuration:1.2
                              delay:1.0
                            options:UIViewAnimationOptionCurveEaseIn
                         animations:^{
                             
                             self.viewFade.alpha = 0;
                         
                         
                         }
                         completion:^(BOOL finished){
                             
                             
                             [self.viewFade setHidden:YES];
                             fade=1;
                         }
         ];

        
    }else{
        
          [self.viewFade setHidden:YES];
    }
    

        [super viewDidLoad];
    
        
    itemPayment = [[ItemPayment alloc]init];
    
    itemPayment.user = [[User alloc]init];
    
    itemPayment.descriptionItem = @"Dentro de cada cápsula encontram-se os melhores cafés do mundo, misturados, torrados e moídos.";
    itemPayment.nameItem =  @"Café Espresso";
    itemPayment.valueItem = @"2.65";

    self.navigationController.navigationBarHidden = YES;
    
    
    [self.homeCollectionView registerNib:[UINib nibWithNibName:@"HomeCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"HomeCollectionViewCell_XIB"];
    
    if (self.view.frame.size.height == 812) {
        self.constrainHeader.constant = CONSTRAINSHEIGHTVIEW;
        
    }
    
  }

-(void)viewDidAppear:(BOOL)animated{
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (IBAction)menu:(id)sender {
    
    [[SlideNavigationController sharedInstance] toggleLeftMenu];
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 1;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    HomeCollectionViewCell* cell = (HomeCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"HomeCollectionViewCell_XIB" forIndexPath:indexPath];
    
    
    cell.responseObjectProduct = itemPayment;
    
    CGSize newSize =   CGSizeMake (640 , 314);
    cell.image.image = [self fitImage:[UIImage imageNamed:@"IMG_CAFE"] inBox:newSize withBackground:[UIColor blackColor]];
    
    NSString *htmlString = itemPayment.descriptionItem;
    
    NSAttributedString *attributedString = [[NSAttributedString alloc]
                                            initWithData: [htmlString dataUsingEncoding:NSUnicodeStringEncoding]
                                            options: @{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType }
                                            documentAttributes: nil
                                            error: nil
                                            ];
    
    NSMutableAttributedString *res = [attributedString mutableCopy];
    [res beginEditing];
    [res enumerateAttribute:NSFontAttributeName
                    inRange:NSMakeRange(0, res.length)
                    options:0
                 usingBlock:^(id value, NSRange range, BOOL *stop) {
                     if (value) {
                         UIFont *newFont = [UIFont fontWithName:@"Verdana" size:13.0];
                         [res addAttribute:NSFontAttributeName value:newFont range:range];
                         [res addAttribute:NSForegroundColorAttributeName
                                     value:UIColorFromHex(0x828282)
                                     range:range];
                     }
                 }];
    [res endEditing];
    [cell.descriptionProduct setAttributedText:res];
    
    cell.nameProduct.text = itemPayment.nameItem;
    
    
    NSString * valueProduct = [self formatReal: itemPayment.valueItem eMostrarSimbolo:NO];
        
    
    NSMutableAttributedString *centralizaCifraoMoedaRealString = [[NSMutableAttributedString alloc] initWithString: [NSString stringWithFormat:@"R$ %@",valueProduct ]];
    
    NSRange bigStringRange = NSMakeRange(0, 2);
    [centralizaCifraoMoedaRealString beginEditing];
    [centralizaCifraoMoedaRealString addAttribute:NSFontAttributeName
                                            value:[UIFont systemFontOfSize:15]
                                            range:bigStringRange];
    [centralizaCifraoMoedaRealString addAttribute:NSBaselineOffsetAttributeName
                                            value:[NSNumber numberWithFloat:3.5]
                                            range:bigStringRange];
    [centralizaCifraoMoedaRealString endEditing];
    cell.valueProduct.attributedText = centralizaCifraoMoedaRealString;
    cell.viewController = self.navigationController;
    
    return cell;

}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat width = collectionView.frame.size.width;
    
    switch (indexPath.row) {
        case 0:
        {
            return CGSizeMake(width, 550);
        }
            break;
            
        default:
            return CGSizeMake(width, 300);
            break;
    }
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 0.0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 0.0;
}


- (UIImage*) fitImage:(UIImage*)image inBox:(CGSize)size withBackground:(UIColor*)color {
    
    float widthFactor = size.width / image.size.width;
    float heightFactor = size.height / image.size.height;
    
    CGSize scaledSize = size;
    if (widthFactor<heightFactor) {
        scaledSize.width = size.width;
        scaledSize.height = image.size.height * widthFactor;
    } else {
        scaledSize.width = image.size.width * heightFactor;
        scaledSize.height = size.height;
    }
    
    UIGraphicsBeginImageContextWithOptions( size, NO, 0.0 );
    
    float marginX = (size.width-scaledSize.width)/2;
    float marginY = (size.height-scaledSize.height)/2;
    CGRect scaledImageRect = CGRectMake(marginX, marginY, scaledSize.width, scaledSize.height );
    
    UIImage* temp = UIGraphicsGetImageFromCurrentImageContext();
    [color set];
    UIRectFill(CGRectMake(0.0, 0.0, temp.size.width, temp.size.height));
    [image drawInRect:scaledImageRect];
    
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return scaledImage;
}

-(NSString*) formatReal: (NSString*) valor eMostrarSimbolo:(BOOL) mostrarSimbolo {
    
    NSDecimalNumber *amountNumber = [NSDecimalNumber decimalNumberWithString:valor];
    
    NSNumberFormatter *currencyStyle = [[NSNumberFormatter alloc] init];
    [currencyStyle setCurrencyCode:@"BRL"];
    [currencyStyle setCurrencyDecimalSeparator:@","];
    [currencyStyle setGroupingSeparator:@"."];
    
    if(mostrarSimbolo)
        [currencyStyle setCurrencySymbol:@"R$"];
    else
        [currencyStyle setCurrencySymbol:@""];
    
    [currencyStyle setNumberStyle: NSNumberFormatterCurrencyStyle];
    [currencyStyle setMaximumFractionDigits:2];
    [currencyStyle setRoundingMode: NSNumberFormatterRoundDown];
    NSString *currency = [currencyStyle stringFromNumber:amountNumber];
    return currency;
    
    
}

@end
