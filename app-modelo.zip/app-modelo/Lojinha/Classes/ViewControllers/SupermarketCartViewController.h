//
//  SupermarketCartViewController.h
//  Lojinha
//
//  Created by TQI on 22/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemPayment.h"

@interface SupermarketCartViewController : UIViewController

@property    ItemPayment * responseObjectProduct;
+ (void)sharedInstance:(UIViewController *)controller;
+ (instancetype)sharedInstance;
-(void)setValuePayment:(int)itens;
@end
