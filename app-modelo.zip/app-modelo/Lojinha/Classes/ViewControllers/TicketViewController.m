//
//  TicketViewController.m
//  CheckOutPagSeguro
//
//  Created by TQI on 17/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import "TicketViewController.h"
#import "HomeViewController.h"
#import "UIImage+PDF.h"
#import "Features.h"
#import "Constants.h"
@interface TicketViewController ()
@property (weak, nonatomic) IBOutlet UILabel *lblMenssageSucess;
@property (weak, nonatomic) IBOutlet UILabel *lblTicketText;
@property (weak, nonatomic) IBOutlet UIButton *btnDownloadTicket;
@property (weak, nonatomic) IBOutlet UIView *viewResult;
@property (weak, nonatomic) IBOutlet UIButton *btnConclusion;
@property (weak, nonatomic) IBOutlet UIButton *textTapped;

- (IBAction)btnConclusion:(id)sender;
- (IBAction)btnDownloadTicket:(id)sender;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constrainHeader;

@end

@implementation TicketViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.view.frame.size.height == 812) {
        self.constrainHeader.constant = CONSTRAINSHEIGHTVIEW;
        
    }
    
    [self setLayoutViews:self.viewResult valid:NO];
    [self setLayoutViews:self.btnDownloadTicket valid:NO];
    
    self.textTapped.layer.cornerRadius = 5;
    self.textTapped.layer.masksToBounds = NO;
    
    self.btnConclusion.layer.cornerRadius = 5;
    self.btnConclusion.layer.masksToBounds = NO;
    
    [self setMaskTicktText];
    
}

-(void)setMaskTicktText{
    
    if (self.result[@"bookletNumber"]) {
           NSString * line = self.result[@"bookletNumber"];
        
        if (line.length==47) {
            
            NSString * partLine1 = [line substringWithRange: NSMakeRange(0, 5)];
            NSString * partLine2 = [line substringWithRange: NSMakeRange(5, 5)];
            NSString * partLine3 = [line substringWithRange: NSMakeRange(10, 5)];
            NSString * partLine4 = [line substringWithRange: NSMakeRange(15, 6)];
            NSString * partLine5 = [line substringWithRange: NSMakeRange(21, 5)];
            NSString * partLine6 = [line substringWithRange: NSMakeRange(26, 6)];
            NSString * partLine7 = [line substringWithRange: NSMakeRange(32, 1)];
            NSString * partLine8 = [line substringWithRange: NSMakeRange(33, 14)];
            
            self.lblTicketText.text = [NSString stringWithFormat:@"%@.%@ %@.%@ %@.%@ %@ %@",partLine1,partLine2,partLine3,partLine4,partLine5,partLine6,partLine7,partLine8];
        }
    }
}



- (IBAction) textTapped:(id)sender{
    
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    [pasteboard setString:self.lblTicketText.text];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)setLayoutViews:(UIView*)view valid:(BOOL)valid{
    
    view.layer.masksToBounds = valid;
    view.layer.shadowOffset = CGSizeMake(0, 0);
    view.layer.shadowRadius = 3;
    view.layer.shadowOpacity = 0.7;
    view.layer.cornerRadius = 5;
    
}


- (IBAction)btnConclusion:(id)sender {

    [self.navigationController popToRootViewControllerAnimated:YES];
    
    
}


- (IBAction)btnDownloadTicket:(id)sender {
    
    [Features startProgressBar:self.view];
    
    NSURL *fileURL = [NSURL URLWithString:self.result[@"paymentLink"]];
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithURL:fileURL completionHandler:^(NSData *data,
                                                          NSURLResponse *response,
                                                          NSError *error)
      {
         
          if(!error){
              NSString *filePath = [NSTemporaryDirectory() stringByAppendingPathComponent:[response suggestedFilename]];
              [data writeToFile:filePath atomically:YES];
              
              BOOL checkExist = [[NSFileManager defaultManager] fileExistsAtPath:filePath isDirectory:nil];
              if (checkExist)
              {
                  NSData *data = [[NSFileManager defaultManager] contentsAtPath:filePath];
                  UIImage *img = [ UIImage imageWithPDFData:data atSize:CGSizeMake( 2479, 3508 ) ];
                  
                  UIImageWriteToSavedPhotosAlbum(img, nil, nil, nil);
                  
                  [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                      UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Boleto"
                                                                      message:@"Boleto salvo na galeria de imagens do celular!"
                                                                     delegate:self
                                                            cancelButtonTitle:@"OK"
                                                            otherButtonTitles:nil];
                      [alert show];
                      
                      [Features stopProgressBar:self.view];

                  }];
                  
              
                  
                  
                  
              }
              
              
          }else{
              
               [Features stopProgressBar:self.view];
              UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Boleto"
                                                              message:@"Erro ao salvar boleto!"
                                                             delegate:self
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles:nil];
              
               [alert show];

          }
          
      }] resume];
    
}
@end
