//
//  MenuViewController.m
//  MovieStars
//
//  Created by Luis  Teodoro on 04/01/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import "MenuViewController.h"
#import "MenuCell.h"
#import "SlideNavigationController.h"
#import "HomeViewController.h"
#import "Constants.h"
#import <PSCheckoutLib/PSCheckoutWallet.h>
#import "AboutViewController.h"


static int sectionView;

@interface MenuViewController ()<PSWalletDelegate>{
    NSMutableIndexSet *expandedSections;
    
    id controllerView;
}
- (IBAction)doLogout:(id)sender;
@property NSArray *cardArray;
@end

@implementation MenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (!expandedSections){
        expandedSections = [[NSMutableIndexSet alloc] init];
    }
    
    if (sectionView == '\0'){
        sectionView=0;
    }
    [self.tableViewMenu reloadData];
    
    self.profileNameLabel.text = @"Luis Teodoro";
    self.profileEmailLabel.text = @"luisteodoro.jr@gmail.com";
    self.profileAvatarImageView.image = [UIImage imageNamed:@"avatar"];
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MenuCell *cell = (MenuCell*)[tableView dequeueReusableCellWithIdentifier:@"MenuCell"];
    if (cell == nil) {
        cell = [[MenuCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MenuCell"];
    }
    cell.indexPath = indexPath;
    [cell setupCellForIndexPath];
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==sectionView) {
        
        [tableView selectRowAtIndexPath:indexPath
                               animated:NO
                         scrollPosition:UITableViewScrollPositionMiddle];
        cell.backgroundColor =  UIColorFromHex(0xEDEDED);
    }
}

+(void)setWillDisplayCellView:(int)section{
    sectionView=section;
    [[SlideNavigationController sharedInstance].leftMenu viewDidLoad];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.section) {
        case 0:{
            
            [MenuViewController setWillDisplayCellView:0];
            NSString *vcID = @"HomeViewController";
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            HomeViewController *vc = [storyboard instantiateViewControllerWithIdentifier:vcID];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc withSlideOutAnimation:NO andCompletion:nil];
        }
            break;
        case 1:{
            [MenuViewController setWillDisplayCellView:1];
            NSString *vcID = @"AboutViewController";
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            AboutViewController *vc = [storyboard instantiateViewControllerWithIdentifier:vcID];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc withSlideOutAnimation:NO andCompletion:nil];
        }
            break;
            
        default:
            break;
    }
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    return 60;
}
- (IBAction)doLogout:(id)sender {
    
    
    UIAlertView *alertaConfirmacao = [[UIAlertView alloc] initWithTitle:@"Deseja fazer logout da sua conta PagSeguro?" message:@"" delegate:self cancelButtonTitle:@"Não" otherButtonTitles:@"Sim", nil];
    
    [alertaConfirmacao setTag: 10];
    [alertaConfirmacao show];
    
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if([alertView tag] == 10) {
        if (buttonIndex == 1)
        {
            PSCheckoutWallet * psWallet = [[PSCheckoutWallet alloc] initWithParentViewController:self];
            psWallet.delegate = self;
            [psWallet logout];
            
            [MenuViewController setWillDisplayCellView:0];
            NSString *vcID = @"HomeViewController";
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            HomeViewController *vc = [storyboard instantiateViewControllerWithIdentifier:vcID];
            [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc withSlideOutAnimation:NO andCompletion:nil];
            
        }
        
    }
    
}
@end
