//
//  FormOfPaymentViewController.m
//  Lojinha
//
//  Created by TQI on 09/05/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "FormOfPaymentViewController.h"
#import <PSCheckoutLib/AuthorizationLib.h>
#import <PSCheckoutLib/PSWallet.h>
#import "Features.h"
#import "CardView.h"
#import "Constants.h"
#import "MiscUtils.h"
#import "DataCardViewController.h"
#import "ItemPayment.h"
#import "PaymentViewController.h"
#import "UserDataViewController.h"
#import "PaymentConclusionViewController.h"

@interface FormOfPaymentViewController ()<PSWalletDelegate>

- (IBAction)cardCreditTransparent:(id)sender;
- (IBAction)cardCreditTransparentDefault:(id)sender;
- (IBAction)ticketPayment:(id)sender;
- (IBAction)back:(id)sender;
- (IBAction)confirmationPayment:(id)sender;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *formsConstrains;

@property (weak, nonatomic) IBOutlet UIButton *cardCreditTransparent;
@property (weak, nonatomic) IBOutlet UIButton *cardCreditTransparentDefault;
@property (weak, nonatomic) IBOutlet UIButton *ticketPayment;

@property (weak, nonatomic) IBOutlet UILabel *mensageTicket;

@property (weak, nonatomic) IBOutlet UIButton *confirmationPayment;

@property (weak, nonatomic) IBOutlet UIImageView *viewCardCreditTransparent;
@property (weak, nonatomic) IBOutlet UIImageView *viewCardCreditTransparentDefault;
@property (weak, nonatomic) IBOutlet UIImageView *viewTicketPayment;

@property (weak, nonatomic) IBOutlet UILabel *lblCardCreditTransparent;
@property (weak, nonatomic) IBOutlet UILabel *lblTicketPayment;
@property (weak, nonatomic) IBOutlet UIButton *back;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constrainHeader;

@property PSWallet *psWallet;


@end

@implementation FormOfPaymentViewController

+(NSString *)getformOfPaymentSelected{
    
    return formOfPaymentSelected;
}

+(void)setformSelected:(NSString *) itemSelected{
    
     formOfPaymentSelected = itemSelected;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    
    
    if([[UIScreen mainScreen] bounds].size.height == 480.0f){
        
        self.formsConstrains.constant = 110;
    }else{
        
        
        self.formsConstrains.constant = 150;
    }
    
    
    [self.confirmationPayment setHidden:YES];
    
    [self.cardCreditTransparent setSelected:NO];
    [self.ticketPayment setSelected:NO];
    [self.cardCreditTransparentDefault setSelected:NO];

    self.confirmationPayment.layer.masksToBounds = NO;
    self.confirmationPayment.layer.cornerRadius = 5;
    

    [[AuthorizationLib sharedManager] setEmail:@"exemplo@bol.com.br"
                                     withToken:@"10291902189212891289"
                                       appName:@"App-Modelo"];

    
    
    if (!self.psWallet) {
        self.psWallet = [[PSWallet alloc] initWithParentViewController:self];
        self.psWallet.delegate = self;
        
        
    }
    UIView * viewButton = [self.psWallet createButtonPagSeguro];
    
    viewButton.frame = CGRectMake(0, 70, self.view.frame.size.width, 100);
    
    if (self.view.frame.size.height == 812) {
        self.constrainHeader.constant = CONSTRAINSHEIGHTVIEW;
        viewButton.frame = CGRectMake(0, 90, self.view.frame.size.width, 100);

    }
    
    
    [self.view addSubview:viewButton];
    
    self.psWallet.amountItemPaymentBtnPagSeguro = self.selectedProduct.valueItem;
    self.psWallet.descriptionPaymentBtnPagSeguro = self.selectedProduct.descriptionItem;
    self.psWallet.itemQuantityPaymentBtnPagSeguro = [self.selectedProduct.amountAll intValue];
    
    [self.mensageTicket setHidden:YES];
    
}

-(void)viewDidAppear:(BOOL)animated{
    
    if (self.ticketPayment.selected) {
        [self.mensageTicket setHidden:NO];

    }else{
        
        [self.mensageTicket setHidden:YES];

    }
    

}



- (void)psWalletDidFinishPaymentWithSuccess:(NSDictionary *)success{
    [Features stopProgressBar:self.view];
    
    [self paymentoConclusion:@"ICN_CONF" message:@"Seu pagamento foi aprovado!"];

    
}


- (void)psWalletDidFailPaymentWithError:(NSError *)error{
    NSLog(@"%@",error);
    
    [Features stopProgressBar:self.view];
    if (error.code==1009) {
        
        [self showAlertViewWithMessage:error.userInfo[@"message"] tag:20];
        
    }else if (error.code==1000) {
        [self showAlertViewWithMessage:@"Selecione um cartão para pagamento" tag:10];
        
    }else{
   
        [self paymentoConclusion:@"ICN_ERROR" message:error.userInfo[@"message"]];
        
    }
    
}

- (void)psWalletDidFailUserMainCardWithError:(NSError *)error{
    NSLog(@"%@",error);
    [Features stopProgressBar:self.view];
    
}

- (void)showAlertViewWithMessage:(NSString*)message tag:(int)tag{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PagSeguro"
                                                    message:message
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil, nil];
    alert.delegate = self;
    alert.tag =tag;
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    
        [self.psWallet openCardList];
        
  
}

- (IBAction)getListCard:(id)sender {
    
    [self.psWallet openCardList];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


- (IBAction)back:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

-(NSString*) formatStringDecimal: (NSString*) stringSemFormato {
    
    NSMutableString *strFormatada = [[NSMutableString alloc] initWithString:stringSemFormato];
    NSInteger tamanhoSemFormato = [stringSemFormato length];
    
    if(tamanhoSemFormato > 2 ) {
        [strFormatada insertString:@"." atIndex: (tamanhoSemFormato -2)];
    } else if(tamanhoSemFormato == 2) {
        [strFormatada insertString:@"0." atIndex: 0];
    } else if(tamanhoSemFormato == 1) {
        [strFormatada insertString:@"0.0" atIndex: 0];
    }
    
    return strFormatada;
}

-(NSString *)formatValueDecimal:(NSString *)valor{
    
    valor =[valor stringByReplacingOccurrencesOfString:@"."
                                            withString:@""];
    valor =[valor stringByReplacingOccurrencesOfString:@","
                                            withString:@""];
    valor =[valor stringByReplacingOccurrencesOfString:@"R$"
                                            withString:@""];
    valor = [self formatStringDecimal:valor];
    
    return valor;
    
}


- (IBAction)confirmationPayment:(id)sender {
    
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    
    self.selectedProduct.imageItem =  @"capsula";
    
    if (self.cardCreditTransparent.selected) {
        
        
        self.selectedProduct.typePayment = [FormOfPaymentViewController getformOfPaymentSelected];
        DataCardViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"DataCardViewController"];
        paymentViewController.itemPayment = self.selectedProduct;
        
        [DataCardViewController sharedInstance:paymentViewController];
        
        [self.navigationController pushViewController:paymentViewController animated:YES];
        
    }else   if (self.cardCreditTransparentDefault.selected) {
        
        
        self.selectedProduct.typePayment = [FormOfPaymentViewController getformOfPaymentSelected];
        
        DataCardViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"DataCardViewController"];
        paymentViewController.itemPayment = self.selectedProduct;
        
        [DataCardViewController sharedInstance:paymentViewController];
        
        [self.navigationController pushViewController:paymentViewController animated:YES];
        
    }
    else  if (self.ticketPayment.selected) {
        
        self.selectedProduct.typePayment = [FormOfPaymentViewController getformOfPaymentSelected];
        self.selectedProduct.valueInstallment = @"Boleto";
        UserDataViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"UserDataViewController"];
        
        paymentViewController.itemPayment = self.selectedProduct;
        
        [self.navigationController pushViewController:paymentViewController animated:YES];
        
    }
}

-(void)paymentoConclusion:(NSString*)image message:(NSString *)message{
    
    
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    PaymentConclusionViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"PaymentConclusionViewController"];
    
    paymentViewController.imageConclusionResponse=image;
    paymentViewController.messageConclusionResponse=message;
    
    [self.navigationController pushViewController:paymentViewController animated:YES];

}



- (IBAction)cardCreditTransparent:(id)sender {
    
    [FormOfPaymentViewController setformSelected:@"gateway"];

    
    [self.mensageTicket setHidden:YES];
    self.viewCardCreditTransparent.image = [UIImage imageNamed:@"check"];
    self.viewCardCreditTransparentDefault.image = nil;
    self.viewTicketPayment.image = nil;
    
    
    [self.cardCreditTransparent setSelected:YES];
    [self.ticketPayment setSelected:NO];
    [self.cardCreditTransparentDefault setSelected:NO];

    
    [self.confirmationPayment setHidden:NO];
    
    
}

- (IBAction)ticketPayment:(id)sender {
    
    [FormOfPaymentViewController setformSelected:@"ticket"];

    
    [self.mensageTicket setHidden:NO];

    self.viewCardCreditTransparent.image = nil;
    self.viewCardCreditTransparentDefault.image =nil;
    self.viewTicketPayment.image = [UIImage imageNamed:@"check"];
    
    [self.cardCreditTransparent setSelected:NO];
    [self.ticketPayment setSelected:YES];
    [self.cardCreditTransparentDefault setSelected:NO];

    [self.confirmationPayment setHidden:NO];
    
    
    
}

- (IBAction)cardCreditTransparentDefault:(id)sender{
    
    [FormOfPaymentViewController setformSelected:@"default"];
    
    
    [self.mensageTicket setHidden:YES];
    
    self.viewCardCreditTransparent.image = nil;
    self.viewCardCreditTransparentDefault.image = [UIImage imageNamed:@"check"];
    self.viewTicketPayment.image = nil;

    
    [self.cardCreditTransparent setSelected:NO];
    [self.ticketPayment setSelected:NO];
    [self.cardCreditTransparentDefault setSelected:YES];

    
    [self.confirmationPayment setHidden:NO];

}
@end
