//
//  TicketViewController.h
//  CheckOutPagSeguro
//
//  Created by TQI on 17/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TicketViewController : UIViewController

@property NSDictionary * result;

@end
