//
//  SupermarketCartViewController.m
//  Lojinha
//
//  Created by TQI on 22/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "SupermarketCartViewController.h"
#import "SupermarketCartCollectionViewCell.h"
#import "Constants.h"
#import "SupermarketCarEmptytCollectionViewCell.h"
#import "Features.h"
#import "MiscUtils.h"
#import "FormOfPaymentViewController.h"


double valueProductItem;
int itensAmountOrder;
static SupermarketCartViewController *sharedInstance;
int heightKeyBoard;

@interface SupermarketCartViewController ()< UICollectionViewDelegate, UICollectionViewDataSource, UITextFieldDelegate>{
    
    ItemPayment * listProduct;
    
}
@property (weak, nonatomic) IBOutlet UIButton *back;
- (IBAction)back:(id)sender;
@property (weak, nonatomic) IBOutlet UICollectionView * supermarketCartCollectionView;
@property (weak, nonatomic) IBOutlet UIButton *finishOrder;
- (IBAction)finishOrder:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *valueOrder;
@property (weak, nonatomic) IBOutlet UIView *viewFinish;
@property (weak, nonatomic) IBOutlet UIView *viewCard;
@property (weak, nonatomic) IBOutlet UITextField *txtDiscountCoupon;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constrainDiscountCoupon;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constrainHeader;


@end

@implementation SupermarketCartViewController


+ (void)sharedInstance:(UIViewController *)controller
{
    sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = (SupermarketCartViewController *)controller;
    });
    
}
+ (instancetype)sharedInstance{
    
    return sharedInstance;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.viewCard setHidden:YES];
    itensAmountOrder=1;
    heightKeyBoard = 258;
    self.finishOrder.layer.masksToBounds = NO;
    self.finishOrder.layer.cornerRadius = 5;

    
    [self setLayoutViews:self.viewFinish ];
    [self setLayoutViews:self.viewCard ];
    
    [self.supermarketCartCollectionView registerNib:[UINib nibWithNibName:@"SupermarketCartCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"SupermarketCartCollectionViewCell_XIB"];
    
    [self.supermarketCartCollectionView registerNib:[UINib nibWithNibName:@"SupermarketCarEmptytCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"SupermarketCarEmptytCollectionViewCell_XIB"];
    
    self.txtDiscountCoupon.delegate = self;
    
    [self inicializaGesto];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    
    NSLog(@"%f", self.view.frame.size.height);
    
    if (self.view.frame.size.height == 812) {
        self.constrainHeader.constant = CONSTRAINSHEIGHTVIEW;

    }
    
    
}

-(void) inicializaGesto {
    UIGestureRecognizer *gesto  = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickForaTeclado)];
    gesto.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:gesto];
}



-(void)clickForaTeclado {
    
    [self.view  endEditing:YES];
     self.constrainDiscountCoupon.constant = 165;
}

- (void)keyboardWasShown:(NSNotification *)notification
{
    
    CGSize keyboardSize = [[[notification userInfo] objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    //Given size may not account for screen rotation
    int height = MIN(keyboardSize.height,keyboardSize.width);
    
    if (height != 0 ){
        
        heightKeyBoard = height;
    }
    
    self.constrainDiscountCoupon.constant = heightKeyBoard + 10;
    
    
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    
  
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    
    
    
    return YES;
}

-(void)viewDidAppear:(BOOL)animated{
    
    [self.finishOrder setEnabled:YES];
    [self.finishOrder setAlpha:1.0];


    listProduct= self.responseObjectProduct ;
    self.constrainDiscountCoupon.constant = 165;

    
    [self.supermarketCartCollectionView reloadData];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)setLayoutViews:(UIView*)view{
    
    view.layer.masksToBounds = NO;
    view.layer.shadowOffset = CGSizeMake(0, 0);
    view.layer.shadowRadius = 3;
    view.layer.shadowOpacity = 0.3;
    
}

-(void)setValuePayment:(int)itens{
    
    itensAmountOrder = itens;
    
    self.valueOrder.text = [NSString stringWithFormat:@"%f",valueProductItem*itens];
    
    NSMutableAttributedString *centralizaCifraoMoedaRealString = [[NSMutableAttributedString alloc] initWithString: [NSString stringWithFormat:@"R$ %@",[self formatReal:  self.valueOrder.text eMostrarSimbolo:NO] ]];
    
    NSRange bigStringRange = NSMakeRange(0, 2);
    [centralizaCifraoMoedaRealString beginEditing];
    [centralizaCifraoMoedaRealString addAttribute:NSFontAttributeName
                                            value:[UIFont systemFontOfSize:15]
                                            range:bigStringRange];
    [centralizaCifraoMoedaRealString addAttribute:NSBaselineOffsetAttributeName
                                            value:[NSNumber numberWithFloat:3.5]
                                            range:bigStringRange];
    [centralizaCifraoMoedaRealString endEditing];
    self.valueOrder.attributedText = centralizaCifraoMoedaRealString;
}

- (IBAction)back:(id)sender {
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 1;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if (listProduct!=nil) {
        SupermarketCartCollectionViewCell* cell = (SupermarketCartCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"SupermarketCartCollectionViewCell_XIB" forIndexPath:indexPath];

        NSString * valueProduct = [self formatReal: listProduct.valueItem eMostrarSimbolo:NO];
        
        
          valueProductItem = [listProduct.valueItem doubleValue];
        
        
        NSMutableAttributedString *centralizaCifraoMoedaRealString = [[NSMutableAttributedString alloc] initWithString: [NSString stringWithFormat:@"R$ %@",valueProduct ]];
        
        NSRange bigStringRange = NSMakeRange(0, 2);
        [centralizaCifraoMoedaRealString beginEditing];
        [centralizaCifraoMoedaRealString addAttribute:NSFontAttributeName
                                                value:[UIFont systemFontOfSize:15]
                                                range:bigStringRange];
        [centralizaCifraoMoedaRealString addAttribute:NSBaselineOffsetAttributeName
                                                value:[NSNumber numberWithFloat:3.5]
                                                range:bigStringRange];
        [centralizaCifraoMoedaRealString endEditing];
        cell.valueItem.attributedText = centralizaCifraoMoedaRealString;
        cell.itensProduct.text=@"1";
        
        [[SupermarketCartViewController sharedInstance]setValuePayment:[cell.itensProduct.text intValue]];
        
        [cell.btnEmpty addTarget:self action:@selector(empty)   forControlEvents:UIControlEventTouchDown];
        
        
        [cell.btnAdd setImage:[UIImage imageNamed:@"addItem-1"] forState:UIControlStateNormal];
        
        [cell.btnRemove setImage:[UIImage imageNamed:@"removeItem"] forState:UIControlStateNormal];
        
        
        return cell;
        
    }else{
        SupermarketCarEmptytCollectionViewCell* cell = (SupermarketCarEmptytCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"SupermarketCarEmptytCollectionViewCell_XIB" forIndexPath:indexPath];
        
        return cell;
    }
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat width = collectionView.frame.size.width;
    
    switch (indexPath.row) {
        case 0:
        {
            if (listProduct==nil) {
                return CGSizeMake(width, 70);
            }
            return CGSizeMake(width, 140);
        }
            break;
            
        default:
            return CGSizeMake(width, 300);
            break;
    }
}

-(void)empty{
    
    [self.finishOrder setEnabled:NO];
    
    [self.finishOrder setAlpha:0.5];
    
    listProduct=nil;
    
    [self.supermarketCartCollectionView reloadData];
    
    [[SupermarketCartViewController sharedInstance]setValuePayment:0];
    
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 0.0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 0.0;
}


- (UIImage*) fitImage:(UIImage*)image inBox:(CGSize)size withBackground:(UIColor*)color {
    
    float widthFactor = size.width / image.size.width;
    float heightFactor = size.height / image.size.height;
    
    CGSize scaledSize = size;
    if (widthFactor<heightFactor) {
        scaledSize.width = size.width;
        scaledSize.height = image.size.height * widthFactor;
    } else {
        scaledSize.width = image.size.width * heightFactor;
        scaledSize.height = size.height;
    }
    
    UIGraphicsBeginImageContextWithOptions( size, NO, 0.0 );
    
    float marginX = (size.width-scaledSize.width)/2;
    float marginY = (size.height-scaledSize.height)/2;
    CGRect scaledImageRect = CGRectMake(marginX, marginY, scaledSize.width, scaledSize.height );
    
    UIImage* temp = UIGraphicsGetImageFromCurrentImageContext();
    [color set];
    UIRectFill(CGRectMake(0.0, 0.0, temp.size.width, temp.size.height));
    [image drawInRect:scaledImageRect];
    
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return scaledImage;
}

-(NSString*) formatReal: (NSString*) valor eMostrarSimbolo:(BOOL) mostrarSimbolo {
    
    NSDecimalNumber *amountNumber = [NSDecimalNumber decimalNumberWithString:valor];
    
    NSNumberFormatter *currencyStyle = [[NSNumberFormatter alloc] init];
    [currencyStyle setCurrencyCode:@"BRL"];
    [currencyStyle setCurrencyDecimalSeparator:@","];
    [currencyStyle setGroupingSeparator:@"."];
    
    if(mostrarSimbolo)
        [currencyStyle setCurrencySymbol:@"R$"];
    else
        [currencyStyle setCurrencySymbol:@""];
    
    [currencyStyle setNumberStyle: NSNumberFormatterCurrencyStyle];
    [currencyStyle setMaximumFractionDigits:2];
    [currencyStyle setRoundingMode: NSNumberFormatterRoundDown];
    NSString *currency = [currencyStyle stringFromNumber:amountNumber];
    return currency;
    
    
}

- (IBAction)finishOrder:(id)sender {
    
    
    UIStoryboard *board=[UIStoryboard storyboardWithName:@"Main" bundle:nil];

    FormOfPaymentViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"FormOfPaymentViewController"];
    
    NSString * valor  = [MiscUtils formatValueDecimal:self.valueOrder.text];
    NSString * amount  =[NSString stringWithFormat:@"%d",itensAmountOrder];
    
    NSString * extraAmount = @"0.00";
    
    if ([self.txtDiscountCoupon.text isEqualToString:@"pagseguro"]) {
        extraAmount  =[NSString stringWithFormat:@"-%.2f",([valor doubleValue] * 10.0 / 100)];
        
        valor = [NSString stringWithFormat:@"%.2f", [valor doubleValue] +  [extraAmount doubleValue]];
    }

    self.responseObjectProduct.valueAll = valor;
     self.responseObjectProduct.amountAll = amount;
    self.responseObjectProduct.extraAmount = extraAmount;

    
    paymentViewController.selectedProduct = self.responseObjectProduct;
    
    [self.navigationController pushViewController:paymentViewController animated:YES];
}






@end
