//
//  AboutViewController.m
//  Lojinha
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "AboutViewController.h"
#import "SlideNavigationController.h"
#import "Constants.h"
@interface AboutViewController ()
- (IBAction)menu:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *version;
- (IBAction)linkApp:(id)sender;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constrainHeader;

@end

@implementation AboutViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (self.view.frame.size.height == 812) {
        self.constrainHeader.constant = CONSTRAINSHEIGHTVIEW;
        
    }
    
    
    self.version.text = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)menu:(id)sender {
    
    [[SlideNavigationController sharedInstance] toggleLeftMenu];
    
}

- (IBAction)linkApp:(id)sender {
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://dev.pagseguro.uol.com.br/documentacao/aplicativo-pagseguro/checkout-in-app"]];

}

@end
