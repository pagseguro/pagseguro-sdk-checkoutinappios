//
//  PaymentConclusionViewController.h
//  InAppPurchase
//
//  Created by TQI on 09/02/17.
//  Copyright © 2017 Luis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentConclusionViewController : UIViewController
@property (weak, nonatomic)  NSString *imageConclusionResponse;
@property (weak, nonatomic)  NSString *messageConclusionResponse;
@end
