//
//  AboutViewController.h
//  Lojinha
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController

@end
