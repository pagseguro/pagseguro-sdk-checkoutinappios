//
//  MenuViewController.h
//  MovieStars
//
//  Created by Luis  Teodoro on 04/01/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView    *profileAvatarImageView;
@property (weak, nonatomic) IBOutlet UILabel        *profileNameLabel;
@property (weak, nonatomic) IBOutlet UILabel        *profileEmailLabel;
@property (strong, nonatomic) IBOutlet UITableView *tableViewMenu;
@property (weak, nonatomic) IBOutlet UIView *viewUser;

+(void)setWillDisplayCellView:(int)section;
@end
