//
//  InstallmentsViewController.m
//  CheckOutPagSeguro
//
//  Created by TQI on 20/03/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import "InstallmentsViewController.h"
#import "PaymentViewController.h"
#import "MiscUtils.h"
#import <PSCheckoutLib/PSCheckoutTransparent.h>
#import "Features.h"
#import "UserDataViewController.h"
#import "Constants.h"

#define UIColorFromHex(hexValue) \
[UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16))/255.0 \
green:((float)((hexValue & 0x00FF00) >>  8))/255.0 \
blue:((float)((hexValue & 0x0000FF) >>  0))/255.0 \
alpha:1.0]


@interface InstallmentsViewController ()<UIGuidedViewDataSource, UIGuidedViewDelegate>{
    
    NSMutableArray * installment;
    NSMutableArray * itensInstallment;
    NSString * quantity;
}

@property (strong, nonatomic)  NSString *itemPaymentValueAll;

@property  PSCheckoutTransparent *checkoutTransparent;
@property (weak, nonatomic) IBOutlet UITextField *txtCupom;
@property (weak, nonatomic) IBOutlet UIButton *btnBack;
- (IBAction)btnBack:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *confirmation;
- (IBAction)confirmation:(id)sender;

@property (strong, nonatomic) IBOutlet UIGuidedView *guidedView;
@property (strong, nonatomic) IBOutlet UILabel *lblValueInstallment;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constrainHeader;

@end

@implementation InstallmentsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.view.frame.size.height == 812) {
        self.constrainHeader.constant = CONSTRAINSHEIGHTVIEW;
        
    }
    
    self.guidedView.dataSource = self;
    self.guidedView.delegate = self;
    
   //[self setLayoutViewsDrop:self.viewDropDown ];
    [self setLayoutViews:self.confirmation ];
    //[self setLayoutViews:self.viewItens ];
    
    quantity = @"1";
    
    [self setLayoutViews:self.txtCupom valid:NO];

    
    self.guidedView.lineColor = UIColorFromHex(0x49872F);
    self.guidedView.backgroundLineColor = UIColorFromHex(0x90EE90);
    
    
     self.lblValueInstallment.text =[NSString stringWithFormat:@"%@", [MiscUtils formatReal: self.itemPayment.valueAll eMostrarSimbolo:YES]];
    
    self.itemPaymentValueAll = self.itemPayment.valueAll;
    

}



- (void)viewDidAppear:(BOOL)animated{
    
    [Features startProgressBar:self.view];
    [self.guidedView selectNodeAtIndex:4];

    
     NSString * cardCreditFormatted = [self.numberCard stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    self.checkoutTransparent = [[PSCheckoutTransparent alloc]initWithInstallmentsAmount:[MiscUtils formatValueDecimal:self.itemPayment.valueAll] cardNumber:cardCreditFormatted success:^(BOOL approved, NSDictionary *success) {
        
        [Features stopProgressBar:self.view];
        
        installment = [[NSMutableArray alloc]init];
        
        itensInstallment = [[NSMutableArray alloc]init];
        
        itensInstallment = success[@"installments"];
        
        for (NSDictionary * install in itensInstallment) {
            
            NSString * parcelamento = [NSString stringWithFormat:@"%@x",install[@"quantity"]];
            
            [installment addObject:parcelamento];
            
        }
       
    } failure:^(NSError *error) {
       
        [Features stopProgressBar:self.view];

    }];
    
    
}


-(void)setLayoutViews:(UIView*)view{
    
    view.layer.masksToBounds = NO;
    view.layer.cornerRadius = 5;
    
}

-(void)setLayoutViewsDrop:(UIView*)view{
    
    view.layer.masksToBounds = NO;
    view.layer.shadowOffset = CGSizeMake(0, 0);
    view.layer.shadowRadius = 3;
    view.layer.shadowOpacity = 0.2;
    view.layer.cornerRadius = 5;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBack:(id)sender {
    
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)segmentedControlWasTouched:(int)selectedSegmentIndex {
    
    [self.guidedView selectNodeAtIndex:selectedSegmentIndex];
}

- (BOOL)guidedView:(UIGuidedView *)guidedView willSingleTransitionFromIndex:(NSInteger)index toIndex:(NSInteger)toIndex inDirection:(UIGuidedViewAnimationDirection)direction{
    
    NSLog(@"Will single transition from %li to %li", (long)index, (long)toIndex);
    
    return YES;
}

- (BOOL)guidedView:(UIGuidedView *)guidedView willMultipleTransitionFromIndex:(NSInteger)index toIndex:(NSInteger)toIndex inDirection:(UIGuidedViewAnimationDirection)direction{
    
    NSLog(@"Will multiple transition from %li to %li", (long)index, (long)toIndex);
    
    return YES;
}

- (void)guidedView:(UIGuidedView *)guidedView didSingleTransitionFromIndex:(NSInteger)index toIndex:(NSInteger)toIndex inDirection:(UIGuidedViewAnimationDirection)direction{
    
    NSLog(@"Did single transition from %li to %li", (long)index, (long)toIndex);
}

- (void)guidedView:(UIGuidedView *)guidedView didMultipleTransitionFromIndex:(NSInteger)index toIndex:(NSInteger)toIndex inDirection:(UIGuidedViewAnimationDirection)direction{
    
    NSLog(@"Did multiple transition from %li to %li", (long)index, (long)toIndex);
}

#pragma mark - UIGuidedViewDataSource

- (NSInteger)numberOfNodesForGuidedView:(UIGuidedView *)view {
    return 6;
}

- (NSString *)guidedView:(UIGuidedView *)guidedView titleForNodeAtIndex:(NSInteger)index {
    
    NSString *title = @"";
    
    if(index == 0){
        title = @"Cartão";
    }else if (index == 1){
        title = @"Validade";
    }else if (index == 2){
        title = @"CVV";
    }else if (index == 3){
        title = @"Nome";
    }else if (index == 4){
        title = @"Parcelas";
    }else if (index == 5){
        title = @"Pagamento";
    }
    
    return title;
}


- (IBAction)confirmation:(id)sender {
    
    if ([self.itemPayment.typePayment isEqualToString:@"default"]) {
        
        UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];

        UserDataViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"UserDataViewController"];
        
        self.itemPayment.valueInstallment= self.lblValueInstallment.text;
        self.itemPayment.numberCard=self.numberCard;
        self.itemPayment.expireDate=self.expireDate;
        self.itemPayment.nameUser=self.nameUser;
        self.itemPayment.CVV=self.CVV;
        self.itemPayment.quantity= quantity;
        
        paymentViewController.itemPayment = self.itemPayment;
        
        
        
        [self.navigationController pushViewController:paymentViewController animated:YES];
        
    }else{
        
        
        UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        
        PaymentViewController *paymentViewController = [board instantiateViewControllerWithIdentifier:@"PaymentViewController"];
        
        self.itemPayment.valueInstallment= self.lblValueInstallment.text;
        
        self.itemPayment.valueInstallment= self.lblValueInstallment.text;
        self.itemPayment.numberCard=self.numberCard;
        self.itemPayment.expireDate=self.expireDate;
        self.itemPayment.nameUser=self.nameUser;
        self.itemPayment.CVV=self.CVV;
        self.itemPayment.quantity= quantity;
        paymentViewController.itemPayment = self.itemPayment;
        
        [self.navigationController pushViewController:paymentViewController animated:YES];
    }

    
    
  
}

- (IBAction)dropDown:(id)sender {
    
    
    if(_dropDown.table == nil) {
        
  
        NSArray * arrListContent = [installment copy];
        CGFloat dropDownListHeight = 80;
        if ([arrListContent count]==3) {
            dropDownListHeight = 120;
        }else  if ([arrListContent count]==4) {
            dropDownListHeight = 160;
        }else  if ([arrListContent count]==5) {
            dropDownListHeight = 200;
        }else  if ([arrListContent count]==6) {
            dropDownListHeight = 240;
        }else  if ([arrListContent count]>6) {
            dropDownListHeight = 240;
        }
        
        NSString *direction = @"down"; //Set drop down direction animation
        
        _dropDown = [[SKDropDown alloc]showDropDown:sender withHeight:&dropDownListHeight withData:arrListContent animationDirection:direction];
        _dropDown.delegate = self;
    }
    else {
        [_dropDown hideDropDown:sender];
        _dropDown = [[SKDropDown alloc]init];
    }
    
}


- (void) skDropDownDelegateMethod: (SKDropDown *) sender {
    [self closeDropDown];
}

-(void)closeDropDown{
    
    quantity = _dropDown.element;
    
    quantity = [quantity stringByReplacingOccurrencesOfString:@"x" withString:@""];
    
    
    for (NSDictionary * install in itensInstallment) {
        
        NSString * quantityItem = [NSString stringWithFormat:@"%@",install[@"quantity"]];
        
         NSString * amount = [NSString stringWithFormat:@"%@",install[@"amount"] ];
        
        amount =  [NSString stringWithFormat:@"%.2f",[amount doubleValue]];
        
        if ([quantity isEqualToString:@"1"]) {
            
            self.lblValueInstallment.text =[NSString stringWithFormat:@"%@", [MiscUtils formatReal: self.itemPaymentValueAll eMostrarSimbolo:YES]];
            
            self.itemPayment.valueAll =  self.itemPaymentValueAll;
            
        }else if ([quantityItem isEqualToString:quantity]) {
             self.lblValueInstallment.text =[NSString stringWithFormat:@"%@", [MiscUtils formatReal: amount eMostrarSimbolo:YES]];
            
            self.itemPayment.valueAll = [NSString stringWithFormat:@"%@",install[@"totalAmount"]];
        }
        
     
        
    }

    
    _dropDown=nil;
}

-(void)setLayoutViews:(UIView*)view valid:(BOOL)valid{
    
    view.layer.masksToBounds = valid;
    view.layer.cornerRadius = 5;
    view.layer.shadowOffset = CGSizeMake(0, 0);
    view.layer.shadowRadius = 3;
    view.layer.shadowOpacity = 0.3;
    
}

@end
