//
//  UserAddressDataViewController.m
//  CheckOutPagSeguro
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import "UserAddressDataViewController.h"
#import "UserAddressDataCollectionViewCell.h"
#import "Constants.h"
@interface UserAddressDataViewController ()<UICollectionViewDelegate, UICollectionViewDataSource, UITextFieldDelegate>


@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constrainHeader;


@end

@implementation UserAddressDataViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.view.frame.size.height == 812) {
        self.constrainHeader.constant = CONSTRAINSHEIGHTVIEW;
        
    }
    
    [self setup];
    [self inicializaGesto];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) inicializaGesto {
    UIGestureRecognizer *gesto  = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickForaTeclado)];
    gesto.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:gesto];
}



-(void)clickForaTeclado {
    [self.view  endEditing:YES];
    
}

- (void)setup{
    
    [self.collectionView registerNib:[UINib nibWithNibName:@"UserAddressDataCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"UserAddressDataCollectionViewCell_XIB"];
    
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 1;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:
        {
            UserAddressDataCollectionViewCell *cell = (UserAddressDataCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"UserAddressDataCollectionViewCell_XIB" forIndexPath:indexPath];
            cell.viewController = self.navigationController ;
            cell.itemPayment = self.itemPayment;
            
            return cell;
        }
            break;
            
            
        default:
        {
            UICollectionViewCell *cellView = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
            return cellView;
        }
            break;
    }
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:
        {
            
        }
            break;
        default:
            break;
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat width = collectionView.frame.size.width;
    
    switch (indexPath.row) {
        case 0:
        {
            return CGSizeMake(width, collectionView.frame.size.height-20);
        }
            break;
            
        default:
            return CGSizeMake(width, 300);
            break;
    }
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 0.0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 0.0;
}


- (IBAction)back:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}


@end
