//
//  FormOfPaymentViewController.h
//  Lojinha
//
//  Created by TQI on 09/05/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemPayment.h"

static NSString * formOfPaymentSelected;

@interface FormOfPaymentViewController : UIViewController

@property  ItemPayment * selectedProduct;




+(NSString *)getformOfPaymentSelected;

+(void)setformSelected:(NSString *) itemSelected;

@end
