//
//  UserAddressDataViewController.h
//  CheckOutPagSeguro
//
//  Created by TQI on 12/04/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ItemPayment.h"

@interface UserAddressDataViewController : UIViewController
@property   ItemPayment * itemPayment;

@end
