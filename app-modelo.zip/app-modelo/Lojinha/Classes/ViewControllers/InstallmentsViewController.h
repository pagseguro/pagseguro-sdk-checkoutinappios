//
//  InstallmentsViewController.h
//  CheckOutPagSeguro
//
//  Created by TQI on 20/03/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIGuidedView.h"
#import "ItemPayment.h"
#import "SKDropDown.h"



@interface InstallmentsViewController : UIViewController<SKDropDownDelegate>

@property (strong, nonatomic)  NSString *nameUser;
@property (strong, nonatomic)  NSString *numberCard;
@property (strong, nonatomic)  NSString *expireDate;
@property (strong, nonatomic)  NSString *CVV;
@property   ItemPayment * itemPayment;

@property (weak, nonatomic) IBOutlet UIView *viewDropDown;
@property (strong, nonatomic) IBOutlet UIView *viewItens;

@property (strong, nonatomic) SKDropDown *dropDown;
- (IBAction)dropDown:(id)sender;

@end
