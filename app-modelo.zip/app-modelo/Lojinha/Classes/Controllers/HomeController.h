//
//  HomeController.h
//  Lojinha
//
//  Created by TQI on 21/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constants.h"
//#import "AFHTTPSessionManager.h"
@interface HomeController : NSObject

//@property (strong, nonatomic) AFHTTPSessionManager *manager;
//
//- (void)cancellAllOperations;
//
//- (void)shopSuccess:(void (^)( id responseObject))success
//         failure:(void (^)(NSError *error))failure;
@end
