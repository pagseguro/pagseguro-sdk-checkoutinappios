//
//  HomeController.m
//  Lojinha
//
//  Created by TQI on 21/02/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "HomeController.h"


@implementation HomeController
//- (instancetype)init{
//    self = [super init];
//    if (self) {
//        
//        self.manager = [[AFHTTPSessionManager alloc] initWithBaseURL:[NSURL URLWithString:PS_WALLET_PRD_URL]];
//        
//        self.manager.requestSerializer  = [AFJSONRequestSerializer serializer];
//        self.manager.responseSerializer = [AFJSONResponseSerializer serializer];
//        
//        self.manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/vnd.mbgw.pagseguro.v1+json", @"application/json", nil];
//        
//        self.manager.requestSerializer = [AFJSONRequestSerializer serializer];
//        
//    
//    }
//    return self;
//}
//
//- (void)cancellAllOperations{
//    [self.manager.operationQueue cancelAllOperations];
//}
//
//
//- (void)shopSuccess:(void (^)( id responseObject))success
//         failure:(void (^)(NSError *error))failure{
//    
//    NSString *endpoint = @"/shop/config";
//    
//    [self.manager GET:endpoint parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
//        
//        success(responseObject);
//        
//        NSLog(@"JSON: %@", responseObject);
//    } failure:^(NSURLSessionTask *operation, NSError *error) {
//        
//              failure(error);
//        
//        NSLog(@"Error: %@", error);
//    }];
//    
//    
//    
//}

@end
