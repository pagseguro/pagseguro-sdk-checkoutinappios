//
//  CardView.m
//  Lojinha
//
//  Created by TQI on 09/05/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "CardView.h"



@implementation CardView


-(void)layoutSubviews{
    
    self.layer.masksToBounds = NO;
    self.layer.shadowOffset = CGSizeMake(0, 0);
    self.layer.shadowRadius = 3;
    self.layer.shadowOpacity = 0.3;
    self.layer.cornerRadius = 5.0;

}






@end
