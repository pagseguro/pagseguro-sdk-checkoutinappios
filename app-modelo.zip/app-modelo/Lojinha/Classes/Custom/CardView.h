//
//  CardView.h
//  Lojinha
//
//  Created by TQI on 09/05/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface CardView : UIView

@property (nonatomic) IBInspectable UIColor *someColor;

@end
