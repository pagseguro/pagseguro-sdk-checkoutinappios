

#import "AppDelegate.h"

#ifndef Constants_h
#define Constants_h


#define UIColorFromHex(hexValue) \
[UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16))/255.0 \
green:((float)((hexValue & 0x00FF00) >>  8))/255.0 \
blue:((float)((hexValue & 0x0000FF) >>  0))/255.0 \
alpha:1.0]




#define AppDelegateMacro ((AppDelegate *)[[UIApplication sharedApplication] delegate])

#define CONSTRAINSHEIGHTVIEW 85.0

#endif /* Constants_h */
#define PS_WALLET_PRD_URL @"https://ws.wallet.pagseguro.uol.com.br"
