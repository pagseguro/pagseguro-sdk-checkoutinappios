//
//  PSCheckoutWallet.h
//  PSCheckoutLib
//
//  Created by TQI on 23/10/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <PSCheckoutLib/PSCheckoutAuthorization.h>
#import <PSCheckoutLib/PSWalletCartItem.h>
#import <PSCheckoutLib/PSWalletCard.h>


#define PSWALLET_LIB_VERSION @"2.0.0"

@protocol PSWalletDelegate <NSObject>

@optional

- (void)psWalletDidFinishGetUserMainCard:(PSWalletCard *_Nullable)userMainCard;

- (void)psWalletDidFailUserMainCardWithError:(NSError *_Nullable)error;

- (void)psWalletDidFinishPaymentWithSuccess:(NSDictionary *_Nullable)success;

- (void)psWalletDidFailPaymentWithError:(NSError *_Nullable)error;

@end

@interface PSCheckoutWallet : NSObject

NS_ASSUME_NONNULL_BEGIN
@property id<PSWalletDelegate> _Nullable delegate;

@property NSString * amountItemPaymentBtnPagSeguro;

@property NSString * descriptionPaymentBtnPagSeguro;

@property int itemQuantityPaymentBtnPagSeguro;

- (void)getMainCard;

- (void)openCardList;

- (void)makePaymentForCartItens:(NSArray*)cartItens;

- (void)logout;

- (BOOL)needLogin;

- (NSString*)version;

-(void)updateUserMainCard;

- (UIView * )createButtonPagSeguro;

- (instancetype)initWithParentViewController:(UIViewController*)parentViewController;

NS_ASSUME_NONNULL_END

+(int)getNavigationBarColor;

+(void)setNavigationBarColor:(int)colorHexa;
@end

/*
 1009 - SESSION_EXPIRED (Sessão expirada, refaça a operação e realize login novamente.);
 9000 - NETWORK_ERROR (Falha de conexão);
 9001 - REFUSED_TRANSACTION_ERROR (Transação cancelada ou recusada);
 9002 - CREATE_TRANSACTION_ERROR (Falha ao criar transação);
 9003 - TIME_OUT_CHECK_TRANSACTION (Timeout verificação status da transação);
 9004 - CHECK_TRANSACTION_ERROR (Falha na verificação da transação);
 */


