//
//  PSCheckoutTransparent.h
//  PSCheckoutLib
//
//  Created by TQI on 23/10/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^ApprovalResultBlock)(BOOL approved, NSDictionary * success);
typedef void(^RefusedResultBlock)(NSError *error);

@interface PSCheckoutTransparent : NSObject

/*O PagSeguro é apenas um gateway de pagamento e não realiza análise antifraude das transações. Assim, o chargeback é do vendedor e o PagSeguro não assume o risco sobre suas vendas. Caso esta modalidade faça sentido para o seu negócio e você queira utilizar o Gateway em seu aplicativo, é necessário:
 
 Entrar em contato pelo e-mail checkoutinapp@pagseguro.com.br, informando e-mail e telefone de contato;
 Ter a aprovação do PagSeguro;
 Assinar um contrato, onde estarão os termos que especificam a opção pelo uso do checkout gateway.*/

- (instancetype)initWithPayTransparentGatewayCreditCard:(NSString*)creditCard
                                               expMonth:(NSString *)expMonth
                                                expYear:(NSString *)expYear
                                                    cvv:(NSString *)cvv
                                          amountPayment:(NSString *)amountPayment
                                    quantityPaymentItem:(NSString *)quantityPaymentItem
                                   numberOfInstallments:(NSString *)numberOfInstallments
                                     descriptionPayment:(NSString *)descriptionPayment
                                                success:(ApprovalResultBlock)success
                                                failure:(RefusedResultBlock)failure ;


- (instancetype)initWithPayTransparentDefaultCreditCard:(NSString*)creditCard
                                               expMonth:(NSString *)expMonth
                                                expYear:(NSString *)expYear
                                                    cvv:(NSString *)cvv
                                      amountPaymentItem:(NSString *)amountPaymentItem
                                    quantityPaymentItem:(NSString *)quantityPaymentItem
                                   numberOfInstallments:(NSString *)numberOfInstallments
                                       valueInstallment:(NSString *)valueInstallment
                                     descriptionPayment:(NSString *)descriptionPayment
                                                  email:(NSString *)email
                                                   name:(NSString *)name
                                                    cpf:(NSString *)cpf
                                              birthDate:(NSString *)birthDate
                                          phoneAreaCode:(NSString *)phoneAreaCode
                                            phoneNumber:(NSString *)phoneNumber
                                                country:(NSString *)country
                                                  state:(NSString *)state
                                                   city:(NSString *)city
                                             postalCode:(NSString *)postalCode
                                               district:(NSString *)district
                                                 street:(NSString *)street
                                                 number:(NSString *)number
                                            extraAmount:(NSString *)extraAmount
                                             complement:(NSString *)complement
                                        notificationURL:(NSString *)notificationURL
                                                success:(ApprovalResultBlock)success
                                                failure:(RefusedResultBlock)failure;


- (instancetype)initWithBoletoEmail:(NSString *)email
                               name:(NSString *)name
                                cpf:(NSString *)cpf
                      phoneAreaCode:(NSString *)phoneAreaCode
                        phoneNumber:(NSString *)phoneNumber
                      amountPayment:(NSString *)amountPayment
                quantityPaymentItem:(NSString *)quantityPaymentItem
                 descriptionPayment:(NSString *)descriptionPayment
                            country:(NSString *)country
                              state:(NSString *)state
                               city:(NSString *)city
                         postalCode:(NSString *)postalCode
                           district:(NSString *)district
                             street:(NSString *)street
                             number:(NSString *)number
                        extraAmount:(NSString *)extraAmount
                         complement:(NSString *)complement
                    notificationURL:(NSString *)notificationURL
                            success:(ApprovalResultBlock)success
                            failure:(RefusedResultBlock)failure;

- (instancetype)initWithPostalCode:(NSString *)postalCode
                   success:(ApprovalResultBlock)success
                   failure:(RefusedResultBlock)failure;

- (instancetype)initWithInstallmentsAmount:(NSString *)amount
                                cardNumber:(NSString *)cardNumber success:(ApprovalResultBlock)success failure:(RefusedResultBlock)failure;

@end
