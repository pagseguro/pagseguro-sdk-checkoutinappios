//
//  PSCheckoutAuthorization.h
//  PSCheckoutLib
//
//  Created by TQI on 23/10/17.
//  Copyright © 2017 PagSeguro. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface PSCheckoutAuthorization : NSObject

@property NSString *email;
@property NSString *token;
@property NSString *appName;

@property NSString * ps_WALLET_WS_URL ;
@property NSString * ps_LOGIN_WS_URL ;
@property NSString * ps_REGISTER_WS_URL ;
@property NSString * ps_CARD_WS_URL ;

typedef NS_ENUM(NSInteger,  PSEnvironmentType) {
    PSEnvironmentProd
};

+ (id)sharedManager;

- (void)setEmail:(NSString *)email withToken:(NSString *)token appName:(NSString *)appName environment:(PSEnvironmentType)environment;
@end
NS_ASSUME_NONNULL_END
