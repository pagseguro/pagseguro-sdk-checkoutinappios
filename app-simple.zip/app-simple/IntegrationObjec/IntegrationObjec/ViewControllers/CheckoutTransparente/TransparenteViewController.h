//
//  TransparenteViewController.h
//  IntegrationObjec
//
//  Created by TQI on 25/10/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TransparenteViewController : UIViewController

@end
