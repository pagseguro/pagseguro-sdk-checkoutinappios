//
//  TransparenteViewController.m
//  IntegrationObjec
//
//  Created by TQI on 25/10/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "TransparenteViewController.h"
#import "AuthorizationLib.h"
#import "PSTransparentLib.h"
#import "Features.h"

@interface TransparenteViewController ()<InstallmentsDelegate>
@property PSTransparentLib *checkoutTransparent;

@end

@implementation TransparenteViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    //Parcelar pagamento com dois produtos com valor unitário de R$100,00
    PSTransparentLib *checkoutTransparent = [[PSTransparentLib alloc]init];
    checkoutTransparent.delegateInstallments=self;
    [checkoutTransparent installmentsAmount: @"200.00" cardNumber:@"4929492777068239"];
    
}

//Delegate resultado parcelamento
-(void)installmentsInCard:(NSDictionary *)installments{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (IBAction)creditCard:(id)sender {
    [self paymentCardDefault];
}

- (IBAction)ticket:(id)sender {
    [self paymentTicket];
}

-(void)paymentCardDefault{
    [Features startProgressBar:self.view];
    
    self.checkoutTransparent = [[PSTransparentLib alloc]
                                initWithPayTransparentDefaultCreditCard:@"4219414941342497"
                                expMonth:@"03"
                                expYear:@"22"
                                cvv:@"123"
                                amountPaymentItem:@"100.00"
                                quantityPaymentItem:@"2"
                                numberOfInstallments:@"9"
                                valueInstallment:@"25.68"
                                descriptionPayment:@"venda de roupas"
                                email:@"exemplo@bol.com"
                                name:@"Joao Carlos"
                                cpf:@"41566534470"
                                birthDate:@"10/10/1980"
                                phoneAreaCode:@"11"
                                phoneNumber:@"999997777"
                                country:@"Brasil"
                                state:@"SP"
                                city:@"São Paulo"
                                postalCode:@"01452002"
                                district:@"Jardim Paulistano"
                                street:@"Avenida Brigadeiro Faria Lima"
                                number:@"1384"
                                extraAmount:@"0.00"
                                complement:@"casa"
                                notificationURL:@""
                                success:^(BOOL approved, NSDictionary *success) {
                                    [Features stopProgressBar:self.view];
                                    NSLog(@"%@",success);
                                } failure:^(NSError *error) {
                                    [Features stopProgressBar:self.view];
                                    NSLog(@"%@",error);
                                }];
}

-(void)paymentTicket{
    
    [Features startProgressBar:self.view];
    
    self.checkoutTransparent = [[PSTransparentLib alloc]
                                initWithTicketEmail:@"exemplo@bol.com"
                                name:@"Joao Carlos"
                                cpf:@"41566534470"
                                phoneAreaCode:@"11"
                                phoneNumber:@"999997777"
                                amountPayment:@"10.00"
                                quantityPaymentItem:@"1"
                                descriptionPayment:@"vendas de roupa"
                                country:@"Brasil"
                                state:@"SP"
                                city:@"São Paulo"
                                postalCode:@"01452002"
                                district:@"Jardim Paulistano"
                                street:@"Avenida Brigadeiro Faria Lima"
                                number:@"1384"
                                extraAmount:@""
                                complement:@"Casa"
                                notificationURL:@""
                                success:^(BOOL approved, NSDictionary *success){
                                    [Features stopProgressBar:self.view];
                                    NSLog(@"%@",success);
                                } failure:^(NSError *error) {
                                    [Features stopProgressBar:self.view];
                                    NSLog(@"%@",error);
                                }];
}



@end

