//
//  CarteiraViewController.m
//  IntegrationObjec
//
//  Created by TQI on 25/10/17.
//  Copyright © 2017 Luis Teodoro. All rights reserved.
//

#import "CarteiraViewController.h"
#import "PSCheckoutWallet.h"

@interface CarteiraViewController ()<PSWalletDelegate>
@property PSCheckoutWallet *psWallet;
@property (weak, nonatomic) IBOutlet UIImageView *mainCardBrandImageView;
@property (weak, nonatomic) IBOutlet UILabel *mainCardLastDigitsLabel;
@property PSWalletCard *userMainCard;

@end

@implementation CarteiraViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (!self.psWallet) {
        self.psWallet = [[PSCheckoutWallet alloc] initWithParentViewController:self];
        self.psWallet.delegate = self;
    }
    UIView * viewButton = [self.psWallet createButtonPagSeguro];
    viewButton.frame = CGRectMake(0, 70, self.view.frame.size.width, 100);
    [self.view addSubview:viewButton];
    
    self.psWallet.amountItemPaymentBtnPagSeguro = @"10.00";
    self.psWallet.descriptionPaymentBtnPagSeguro = @"Pagamento de roupas";
    self.psWallet.itemQuantityPaymentBtnPagSeguro = 5;
    
    if (!self.psWallet) {
        self.psWallet = [[PSCheckoutWallet alloc] initWithParentViewController:self];
        self.psWallet.delegate = self;
    }

}

- (void)viewDidAppear:(BOOL)animated{
    if (self.psWallet) {
        if ([self.psWallet needLogin]) {
            [self clearUserMainCard];
        }else{
            [self.psWallet getMainCard];
        }
    }
}

- (IBAction)doLogout:(UIButton *)sender {
    [self clearUserMainCard];
    [self.psWallet logout];
}

- (IBAction)getMainCardTouched:(UIButton *)sender {
    if (self.psWallet) {
        [self.psWallet getMainCard];
    }
}

- (IBAction)openCardList:(UIButton *)sender {
    [self.psWallet openCardList];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)makePaymentTouched:(id)sender {
    if (self.userMainCard) {
        NSNumber * value =    [NSNumber numberWithFloat:10.00] ;
        PSWalletCartItem *item = [[PSWalletCartItem alloc] initWithName:@"Item 0"
                                                                  value:value quantity:1];
        [self.psWallet makePaymentForCartItens:@[item, item, item]];
    }
}
- (void)setupMainCardWithCard:(PSWalletCard*)userMainCard{
    if (userMainCard != nil) {
        self.mainCardBrandImageView.image = userMainCard.brandImage;
        self.mainCardLastDigitsLabel.text = userMainCard.number;
    }
}

- (void)clearUserMainCard{
    self.userMainCard = nil;
    self.mainCardBrandImageView.image = nil;
    self.mainCardLastDigitsLabel.text = @"";
}
- (void)userMainCardSelected:(BOOL)selected{
    
}

#pragma mark - PSWalletDelegate
- (void)psWalletDidFinishPaymentWithSuccess:(NSDictionary *)success{
    NSLog(@"%@",success);
    
}

- (void)psWalletDidFailPaymentWithError:(NSError *)error{
    NSLog(@"%@",error);

}

- (void)psWalletDidFinishGetUserMainCard:(PSWalletCard *)userMainCard{
    if (userMainCard.number==nil) {
        [self clearUserMainCard];
    }else{
        self.userMainCard = userMainCard;
        [self setupMainCardWithCard:userMainCard];
    }
}

- (void)psWalletDidFailUserMainCardWithError:(NSError *)error{
    self.userMainCard = nil;
    NSLog(@"%@",error);

}

@end
